package bdd.demos.cucumberlibrary;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import java.util.List;
import java.util.stream.Collectors;

public class ScreenLibrary extends PageObject {

	public WebDriver driver;
	public boolean driverType = true; 	
    public static final String 	ACTION_ROW = "//div[@class='view' and contains(.,'%s')]";
    public static final String 	COMPLETE_TICKBOX = ".//input[@ng-model='todo.completed']";
    //public static final String	Signupbutton="//form[@id='loginfrm']/div/div[6]/div[1]/a";
    public static final String	Signupbutton="//form[@id='loginfrm']/div/div[4]/div[1]/a";
    public static final String 	UserRegister_Submitbutton="//form[@id='headersignupform']/div[9]/button";
    public static final String 	Uname_label="//body[@id='top']/div[5]/div[1]/div[1]/h3";
    public static final String 	Login_Uname="//*[@id='top']/div[1]/div/div/div[2]/ul/li[9]/a";
    public static final String 	Uname_signout="//*[@id='top']/div[1]/div/div/div[2]/ul/li[9]/ul/li[2]/a";
    
    public static final String 	signin="//*[@id='hdr_user_signin']/span/a[1]";
    public static final String 	signincss="a[contains(@href,'/accounts/login/?next=')]";
    public static final String 	username="html/body/div[1]/form/div[2]/input";
    public static final String 	password="html/body/div[1]/form/div[3]/input";
    public static final String 	signinbtn="//*[@id='signinBtn']";
    public static final String 	bus="html/body/div[1]/div[1]/ul/li[4]";
    public static final String 	copyright="html/body/div[5]/div[2]/div[4]/div[2]";
    public static final String 	userimage="//*[@id='hd_user_widdget']/i";
    public static final String 	signout=".//*[@id='hd_user_widdget']/div/ul/li[6]/a";
    
    // Exceptions
    public static final String 	User_Reg_exception=".//*[@id='headersignupform']/div[2]/div";

    public void addActionCalled(String actionName) {
        $("#new-todo").type(actionName)
                      .then().sendKeys(Keys.ENTER);
    }

    public List<String> getActions() {
        return findAll(".view").stream()
                               .map(WebElementFacade::getText)
                               .collect(Collectors.toList());
    }

  /*  public void filterByStatus(TodoStatusFilter status) {
        findBy("#filters")
                .then().findBy(statusFilterLinkFor(status))
                .then().click();
    }

    private String statusFilterLinkFor(TodoStatusFilter status) {
        return String.format(".//a[.='%s']", status.name());
    }

    public void markComplete(String action) {
        inActionRowFor(action).findBy(COMPLETE_TICKBOX).click();

    }

    private WebElementFacade inActionRowFor(String action) {
        return $(String.format(ACTION_ROW, action));
    }

    public TodoStatus getStatusFor(String action) {
        WebElementFacade actionRow = inActionRowFor(action);
        return isShownAsCompleted(actionRow) ? TodoStatus.Completed : TodoStatus.Active;
    }

    private boolean isShownAsCompleted(WebElementFacade actionRow) {
        return actionRow.find(By.tagName("label")).getCssValue("text-decoration").equals("line-through");
    }*/
}
