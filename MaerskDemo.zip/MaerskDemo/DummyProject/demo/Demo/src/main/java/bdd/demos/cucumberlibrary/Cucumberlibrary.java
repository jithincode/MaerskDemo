package bdd.demos.cucumberlibrary;

import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;

public class Cucumberlibrary{
	public WebDriver driver;
	public boolean driverType = true; 
	Properties locators = new Properties();
	

	 //by passing driver and x_path 
	  public static WebElement findElementByXpath(WebDriver driver, String xpath) throws Throwable
	  {
	    return driver.findElement(By.xpath(xpath));
	  }
	  
	  public static String getTextByXpath(WebDriver driver, String xpath) throws Throwable
	  {
	    return findElementByXpath(driver, xpath).getText();
	  }
	  
	
	  //by passing driver and name 
	  public static WebElement findElementByName(WebDriver driver, String name) throws Throwable
	  {
		return driver.findElement(By.name(name));
	  }
		
	 //by passing driver and id 
	  public static WebElement findElementByid(WebDriver driver, String id) throws Throwable
	  {
		return driver.findElement(By.id(id));
	  }
	  
	  public static WebElement findElementByTagName(WebDriver driver, String tagName) throws Throwable
	  {
	    return driver.findElement(By.tagName(tagName));
	  }
	  
	  public static WebElement findElementByLinkText(WebDriver driver, String linkText) throws Throwable
	  {
	    return driver.findElement(By.linkText(linkText));
	  }
	  
	  public static WebElement findElementByPartialLinkText(WebDriver driver, String partialLinkText) throws Throwable
	  {
	    return driver.findElement(By.partialLinkText(partialLinkText));
	  }
	  
	  public static WebElement findElementByCssSelector(WebDriver driver, String cssSelector) throws Throwable
	  {
	    return driver.findElement(By.cssSelector(cssSelector));
	  }
	  
	  public static void waitForElementToBeVisible(WebDriver driver, String xpath, int timeout) throws Throwable
	  {
	    WebDriverWait wait = new WebDriverWait(driver, timeout);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
	  }
	  
	  public static void waitForElementToBeClickable(WebDriver driver, String xpath, int timeout) throws Throwable
	  {
	    WebDriverWait wait = new WebDriverWait(driver, timeout);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
	  }
	  
	  public static void waitForElementsToBeVisible(WebDriver driver, List<WebElement> listOfAllWebElements, int timeout) throws Throwable
	  {
	    WebDriverWait wait = new WebDriverWait(driver, timeout);
	    wait.until(ExpectedConditions.visibilityOfAllElements(listOfAllWebElements));
	  }
	  
	  public static void waitForElementsToBeClickable(WebDriver driver, List<WebElement> listOfAllWebElements, int timeout) throws Throwable
	  {
	    WebDriverWait wait = new WebDriverWait(driver, timeout);
	    wait.until(ExpectedConditions.visibilityOfAllElements(listOfAllWebElements));
	  }
	  
	  public static void clickOnElementByXpath(WebDriver driver, String xpath) throws Throwable
	  {
	    findElementByXpath(driver, xpath).click();
	  }
	  
	  public static void clickOnElementById(WebDriver driver, String id) throws Throwable
	  {
		  findElementByid(driver, id).click();
	  }
	  
	  public static void clickOnElementByName(WebDriver driver, String name) throws Throwable
	  {
	    findElementByName(driver, name).click();
	  }
	  
	  public static void clickOnElementByCssSelector(WebDriver driver, String cssSelector) throws Throwable
	  {
	    findElementByCssSelector(driver, cssSelector).click();
	  }
	  
	  public static void clickOnElementByLinkText(WebDriver driver, String linkText) throws Throwable
	  {
		  findElementByLinkText(driver, linkText).click();
	  }
	  
	  public static void clickOnElementByPartialLinkText(WebDriver driver, String partialLinkText) throws Throwable 
	  {
	    findElementByPartialLinkText(driver, partialLinkText).click();
	  }
	  
	  public static void clickOnElementByTagName(WebDriver driver, String tagName) throws Throwable
	  {
	    findElementByTagName(driver, tagName).click();
	  } 
	  
	  //by passing driver, Text_value and name 
	  public static void sendTextUsingName(WebDriver driver, String text, String name)  throws Throwable
	  {
	    WebElement element = findElementByName(driver, name);
	    element.sendKeys(new CharSequence[] { text });
	  }
	  
	 //by passing driver, Text_value and x_path 
	  public static void sendTextUsingXpath(WebDriver driver, String text, String xpath) throws Throwable
	  {
	    WebElement element = findElementByXpath(driver, xpath);
	    element.sendKeys(new CharSequence[] { text });
	  }
		
	  //by passing driver, Text_value and id 
	  public static void sendTextUsingId(WebDriver driver, String text, String id) throws Throwable
	  {
	    WebElement element = findElementByid(driver, id);
	    element.sendKeys(new CharSequence[] { text });
	  }		
	 
	  public static void sleep(int sleepTime)
	    throws InterruptedException
	  {
	    Thread.sleep(sleepTime);
	  }	 
	  
	/*  public void driversleep(int sleepTime) throws InterruptedException
	  {
		  driver.manage().timeouts().implicitlyWait(sleepTime, TimeUnit.SECONDS);
	  }	 */
			 	 
	  private static void sendTextUsingCssSelector(WebDriver driver, String text, String cssSelector) throws Throwable
	  {
	    WebElement element = findElementByCssSelector(driver, cssSelector);
	    element.sendKeys(new CharSequence[] { text });
	  }	
	
	  public static void sendTextUsingTagName(WebDriver driver, String text, String tagName) throws Throwable
	  {
	    WebElement element = findElementByTagName(driver, tagName);
	    element.sendKeys(new CharSequence[] { text });
	  }
	  
	  public static void sendTextUsingLinkText(WebDriver driver, String text, String linkText) throws Throwable
	  {
	    WebElement element = findElementByTagName(driver, linkText);
	    element.sendKeys(new CharSequence[] { text });
	  }
	  
	  public static void sendTextUsingPartialLinkText(WebDriver driver, String text, String partialLinkText) throws Throwable
	  {
	    WebElement element = findElementByTagName(driver, partialLinkText);
	    element.sendKeys(new CharSequence[] { text });
	  }
	  
	  public static void selectDropDownUsingXpathAndVisibleText(WebDriver driver, String VisibleText, String xpath) throws Throwable
	  {
	    WebElement element = findElementByXpath(driver, xpath);
	    Select dropDown = new Select(element);
	    dropDown.selectByVisibleText(VisibleText);
	  }
	  
	  public static void selectDropDownUsingIdAndVisibleText(WebDriver driver, String VisibleText, String id) throws Throwable
	  {
	    WebElement element = findElementByid(driver, id);
	    Select dropDown = new Select(element);
	    dropDown.selectByVisibleText(VisibleText);
	  }
	  
	  public static void selectDropDownUsingNameAndVisibleText(WebDriver driver, String VisibleText, String name) throws Throwable
	  {
	    WebElement element = findElementByName(driver, name);
	    Select dropDown = new Select(element);
	    dropDown.selectByVisibleText(VisibleText);
	  }
	  
	  public static void selectDropDownUsingCssSelectorAndVisibleText(WebDriver driver, String VisibleText, String cssSelector) throws Throwable
	  {
	    WebElement element = findElementByCssSelector(driver, cssSelector);
	    Select dropDown = new Select(element);
	    dropDown.selectByVisibleText(VisibleText);
	  }
	  
	  public static void selectDropDownUsingTagNameAndVisibleText(WebDriver driver, String VisibleText, String tagName) throws Throwable
	  {
	    WebElement element = findElementByTagName(driver, tagName);
	    Select dropDown = new Select(element);
	    dropDown.selectByVisibleText(VisibleText);
	  }
	  
	  public static void selectDropDownUsingXpathAndValue(WebDriver driver, String value, String xpath) throws Throwable
	  {
	    WebElement element = findElementByXpath(driver, xpath);
	    Select dropDown = new Select(element);
	    dropDown.selectByValue(value);
	  }
	  
	  public static void selectDropDownUsingIdAndValue(WebDriver driver, String value, String id) throws Throwable
	  {
	    WebElement element = findElementByid(driver, id);
	    Select dropDown = new Select(element);
	    dropDown.selectByValue(value);
	  }
	  
	  public static void selectDropDownUsingNameAndValue(WebDriver driver, String value, String name) throws Throwable
	  {
	    WebElement element = findElementByName(driver, name);
	    Select dropDown = new Select(element);
	    dropDown.selectByValue(value);
	  }
	  
	  public static void selectDropDownUsingCssSelectorAndValue(WebDriver driver, String value, String cssSelector) throws Throwable
	  {
	    WebElement element = findElementByCssSelector(driver, cssSelector);
	    Select dropDown = new Select(element);
	    dropDown.selectByValue(value);
	  }
	  
	  public static void selectDropDownUsingTagNameAndValue(WebDriver driver, String value, String tagName) throws Throwable
	  {
	    WebElement element = findElementByTagName(driver, tagName);
	    Select dropDown = new Select(element);
	    dropDown.selectByValue(value);
	  }
	  
	  public static void selectDropDownUsingXpathAndIndex(WebDriver driver, int index, String xpath) throws Throwable
	  {
	    WebElement element = findElementByXpath(driver, xpath);
	    Select dropDown = new Select(element);
	    dropDown.selectByIndex(index);
	  }
	  
	  public static void selectDropDownUsingIdAndIndex(WebDriver driver, int index, String id) throws Throwable
	  {
	    WebElement element = findElementByid(driver, id);
	    Select dropDown = new Select(element);
	    dropDown.selectByIndex(index);
	  }
	  
	  public static void selectDropDownUsingNameAndIndex(WebDriver driver, int index, String name) throws Throwable
	  {
	    WebElement element = findElementByName(driver, name);
	    Select dropDown = new Select(element);
	    dropDown.selectByIndex(index);
	  }
	  
	  public static void selectDropDownUsingCssSelectorAndIndex(WebDriver driver, int index, String cssSelector) throws Throwable
	  {
	    WebElement element = findElementByCssSelector(driver, cssSelector);
	    Select dropDown = new Select(element);
	    dropDown.selectByIndex(index);
	  }
	  
	  public static void selectDropDownUsingTagNameAndIndex(WebDriver driver, int index, String tagName) throws Throwable
	  {
	    WebElement element = findElementByTagName(driver, tagName);
	    Select dropDown = new Select(element);
	    dropDown.selectByIndex(index);
	  }
	  
	  // Heading UI Properties
	  public static String HeadingFontcolorCss(WebDriver driver, String cssSelector, String CssProperty) throws Throwable
	  {	    
	    return driver.findElement(By.cssSelector(cssSelector)).getCssValue(CssProperty).toString();
	  }	
	  
	  public static String HeadingFontcolorXpath(WebDriver driver, String Xpath, String CssProperty) throws Throwable
	  {	    
	    return driver.findElement(By.xpath(Xpath)).getCssValue(CssProperty).toString();
	  }	 
	  
	  public static String HeadingFontcolorName(WebDriver driver, String Name, String CssProperty) throws Throwable
	  {	    
	    return driver.findElement(By.name(Name)).getCssValue(CssProperty).toString();
	  }	
	  
	  public static String HeadingFontcolorId(WebDriver driver, String Id, String CssProperty) throws Throwable
	  {	    
	    return driver.findElement(By.id(Id)).getCssValue(CssProperty).toString();
	  }	
	  
	  public static String HeadingFontcolorClass(WebDriver driver, String Class, String CssProperty) throws Throwable
	  {	    
	    return driver.findElement(By.className(Class)).getCssValue(CssProperty).toString();
	  }
	  
	  public static String HeadingFontfamily(WebDriver driver, String cssSelector, String CssProperty) throws Throwable
	  {	    
	    return driver.findElement(By.cssSelector(cssSelector)).getCssValue(CssProperty).toString();
	  }
	  
	  // LinkText URL UI Properties
	  public static String LinkurlCss(WebDriver driver, String cssSelector, String CssProperty) throws Throwable
	  {	    
		  return driver.findElement(By.cssSelector(cssSelector)).getAttribute(CssProperty).toString();
	  }   
	  	  	  
	  public static String LinkurlXpath(WebDriver driver, String xpath, String CssProperty) throws Throwable
	  {	    
		  return driver.findElement(By.xpath(xpath)).getAttribute(CssProperty).toString();
	  }   
	  
	  public static String LinkurlName(WebDriver driver, String Name, String CssProperty) throws Throwable
	  {	    
	    return driver.findElement(By.name(Name)).getCssValue(CssProperty).toString();
	  }
	  
	  public static String LinkurlId(WebDriver driver, String Id, String CssProperty) throws Throwable
	  {	    
	    return driver.findElement(By.id(Id)).getCssValue(CssProperty).toString();
	  }
	  
	  public static String LinkurlClass(WebDriver driver, String Class, String CssProperty) throws Throwable
	  {	    
	    return driver.findElement(By.className(Class)).getCssValue(CssProperty).toString();
	  }
	  
	  // TextBox UI Properties
	  public static String Textboxsizing(WebDriver driver, String xpath, String CssProperty) throws Throwable
	  {	    
	    return driver.findElement(By.xpath(xpath)).getCssValue(CssProperty).toString();
	  }

	  public static String Textboxlineheight(WebDriver driver, String xpath, String CssProperty) throws Throwable
	  {	    
		  return driver.findElement(By.xpath(xpath)).getCssValue(CssProperty).toString();
	  }  
	  
	  public static String Textboxpaddingbottom(WebDriver driver, String xpath, String CssProperty) throws Throwable
	  {	    
		  return driver.findElement(By.xpath(xpath)).getCssValue(CssProperty).toString();
	  }  
	  
	  public static String Textboxwidth(WebDriver driver, String xpath, String CssProperty) throws Throwable
	  {	    
		  return driver.findElement(By.xpath(xpath)).getCssValue(CssProperty).toString();
	  } 
	  
	  // Label UI Properties	  
	  public static String LabelFontcolor(WebDriver driver, String cssSelector, String CssValue) throws Throwable
	  {	    
	    return driver.findElement(By.cssSelector(cssSelector)).getCssValue(CssValue).toString();
	  }
	  
	  public static String LabelFontfamily(WebDriver driver, String cssSelector, String CssValue) throws Throwable
	  {	    
	    return driver.findElement(By.cssSelector(cssSelector)).getCssValue(CssValue).toString();
	  }
	  
	  public static String LabelFontsize(WebDriver driver, String cssSelector, String CssValue) throws Throwable
	  {	    
	    return driver.findElement(By.cssSelector(cssSelector)).getCssValue(CssValue).toString();
	  }
	  
	  public static String LabelFontnormalweight(WebDriver driver, String cssSelector, String CssValue) throws Throwable
	  {	    
	    return driver.findElement(By.cssSelector(cssSelector)).getCssValue(CssValue).toString();
	  }
	  
	  public static String LabelFontminwidth(WebDriver driver, String cssSelector, String CssValue) throws Throwable
	  {	    
	    return driver.findElement(By.cssSelector(cssSelector)).getCssValue(CssValue).toString();
	  }
	  
	  // Button UI Properties	  
	  public static String Buttonheight(WebDriver driver, String cssSelector, String CssValue) throws Throwable
	  {	    
	    return driver.findElement(By.cssSelector(cssSelector)).getCssValue(CssValue).toString();
	  }
	  
	  public static String Buttontexttransform(WebDriver driver, String cssSelector, String CssValue) throws Throwable
	  {	    
	    return driver.findElement(By.cssSelector(cssSelector)).getCssValue(CssValue).toString();
	  }
	  
	  public static String Buttonbottomleft(WebDriver driver, String cssSelector, String CssValue) throws Throwable
	  {	    
	    return driver.findElement(By.cssSelector(cssSelector)).getCssValue(CssValue).toString();
	  }  
	  	  
	  public static String Buttonbottomright(WebDriver driver, String cssSelector, String CssValue) throws Throwable
	  {	    
	    return driver.findElement(By.cssSelector(cssSelector)).getCssValue(CssValue).toString();
	  }  
	  	  
	  public static String Buttontopleft(WebDriver driver, String cssSelector, String CssValue) throws Throwable
	  {	    
	    return driver.findElement(By.cssSelector(cssSelector)).getCssValue(CssValue).toString();
	  }
	  
	  public static String Buttontopright(WebDriver driver, String cssSelector, String CssValue) throws Throwable
	  {	    
	    return driver.findElement(By.cssSelector(cssSelector)).getCssValue(CssValue).toString();
	  }  	  

	  public static String Buttoncolor(WebDriver driver, String xpath, String CssValue) throws Throwable
	  {	 
	      return driver.findElement(By.xpath(xpath)).getCssValue(CssValue).toString();
	  }
	  
	  public static void mouseHoverOverElementByXpath(WebDriver driver, String xpath) throws Throwable
	  {
	    WebElement element = findElementByXpath(driver, xpath);
	    Actions actions = new Actions(driver);
	    actions.moveToElement(element);
	    actions.perform();
	  }
	  
	  public static void mouseHoverOverElementByName(WebDriver driver, String name) throws Throwable
	  {
	    WebElement element = findElementByName(driver, name);
	    Actions actions = new Actions(driver);
	    actions.moveToElement(element);
	    actions.perform();
	  }
	  
	  public static void mouseHoverOverElementById(WebDriver driver, String id) throws Throwable
	  {
	    WebElement element = findElementByid(driver, id);
	    Actions actions = new Actions(driver);
	    actions.moveToElement(element);
	    actions.perform();
	  }
	  
	  public static void mouseHoverOverElementByTagName(WebDriver driver, String tagName) throws Throwable
	  {
	    WebElement element = findElementByTagName(driver, tagName);
	    Actions actions = new Actions(driver);
	    actions.moveToElement(element);
	    actions.perform();
	  }
	  
	  public static void mouseHoverOverElementByLinkText(WebDriver driver, String linkText) throws Throwable
	  {
	    WebElement element = findElementByLinkText(driver, linkText);
	    Actions actions = new Actions(driver);
	    actions.moveToElement(element);
	    actions.perform();
	  }
	  
	  public static void mouseHoverOverElementByPartialLinkText(WebDriver driver, String partialLinkText) throws Throwable
	  {
	    WebElement element = findElementByPartialLinkText(driver, partialLinkText);
	    Actions actions = new Actions(driver);
	    actions.moveToElement(element);
	    actions.perform();
	  }
	  
	  //Scroll page
	  public static void scrollDown(WebDriver driver,int downScroll) throws Throwable
	  {
		  ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+downScroll+")");
	  }
	  
	  public static void scrollUp(WebDriver driver,int upScroll) throws Throwable
	  {
		  ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,-"+upScroll+")");
	  }
	  public static void scrollRight(WebDriver driver,int rightScroll) throws Throwable
	  {
		  ((JavascriptExecutor) driver).executeScript("window.scrollTo("+rightScroll+",0)");
	  }
	  
	  public static void scrollLeft(WebDriver driver,int leftScroll) throws Throwable
	  {
		  ((JavascriptExecutor) driver).executeScript("window.scrollTo(-"+leftScroll+",0)");
	  }
	  
	  
	  
	  public static void switchToWindowByName(WebDriver driver, String targetWindowName)
	  {
	    Set<String> windows = driver.getWindowHandles();
	    Iterator<String> itr = windows.iterator();
	    for (int i = 0; i < windows.size() - 1; i++)
	    {
	      itr.next();
	      if (itr.next() == targetWindowName)
	      {
	        driver.switchTo().window(targetWindowName);
	        break;
	      }
	    }
	  }
	  
	  public static void switchToWindowByIndex(WebDriver driver, int targetWindowIndex)
	  {
	    Set<String> windows = driver.getWindowHandles();
	    Iterator<String> itr = windows.iterator();
	    if (targetWindowIndex == 0) {
	      System.out.println("Target window is also the parent window. Please increase the index.");
	    } else {
	      for (int i = 0; i < windows.size() - 1; i++)
	      {
	        String windowToBeSwitchedTo = null;
	        if (i == targetWindowIndex)
	        {
	          driver.switchTo().window(windowToBeSwitchedTo);
	          break;
	        }
	        windowToBeSwitchedTo = (String)itr.next();
	      }
	    }
	  }
	  
	  
	  public static void acceptAlertBox(WebDriver driver)
	  {
	    driver.switchTo().alert().accept();
	  }
	  
	  public static void dismissAlertBox(WebDriver driver)
	  {
	    driver.switchTo().alert().dismiss();
	  }
	  
	  public static void sendTextToAlertBoxAndAccept(WebDriver driver, String text)
	  {
	    Alert alertBox = driver.switchTo().alert();
	    alertBox.sendKeys(text);
	    alertBox.accept();
	  }
	  
}
	


