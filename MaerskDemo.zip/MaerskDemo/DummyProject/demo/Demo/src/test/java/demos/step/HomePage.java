package demos.step;

import net.serenitybdd.core.annotations.findby.By;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;
import java.util.concurrent.TimeUnit;

import javax.validation.constraints.AssertTrue;

import com.thoughtworks.selenium.Selenium;

import bdd.demos.cucumberlibrary.Cucumberlibrary;
import bdd.demos.cucumberlibrary.ScreenLibrary;
import cucumber.api.Scenario;
import junit.framework.Assert;

@DefaultUrl("http://phptravels.net/login")  
@SuppressWarnings("static-access")   
public class HomePage extends PageObject {             


	ScreenLibrary ScrLr;
	
	public void Pagelands() throws Throwable {
    	System.out.println("User is on landing page"); 
    	getDriver().manage().window().maximize();
    }
       
    public void searchSignupButton(String Signup_button) throws Throwable {
    	Cucumberlibrary.clickOnElementByXpath(getDriver(),Signup_button);
    	System.out.println("User Clciks on Sign Up");
    	getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    }
    
    public void SignupFirstnameText(String Firstname_text) throws Throwable {
    	Cucumberlibrary.sendTextUsingName(getDriver(),Firstname_text,"firstname");
    }
    
    public void SignupLastnameText(String Lastname_text) throws Throwable {
    	Cucumberlibrary.sendTextUsingName(getDriver(),Lastname_text,"lastname");
    }

    public void SignupMob_number(String Mob_number_text) throws Throwable {
    	Cucumberlibrary.sendTextUsingName(getDriver(),Mob_number_text,"phone");
    }

    public void SignupEmailID(String EmailID_text) throws Throwable {
    	Cucumberlibrary.sendTextUsingName(getDriver(),EmailID_text,"email");
    }

    public void SignupPassword(String Pwd_text) throws Throwable {
    	Cucumberlibrary.sendTextUsingName(getDriver(),Pwd_text,"password");
    }
    
    public void SignupConfirmPassword(String Confirm_Pwd_text) throws Throwable {
    	Cucumberlibrary.sendTextUsingName(getDriver(),Confirm_Pwd_text,"confirmpassword");
    }
    
    
	public void SignupSubmitButton(String User_Register_SignUp_Button) throws Throwable {
    	Cucumberlibrary.clickOnElementByXpath(getDriver(),User_Register_SignUp_Button);
    	getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
/*    	if(getDriver().findElement(By.xpath(ScrLr.User_Reg_exception)).isDisplayed())
    	{
    	String Exception=getDriver().findElement(By.xpath(ScrLr.User_Reg_exception)).getText();
    	Assert.fail(""+Exception+"");
    	getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	} 
       	*/
    }

	//@SuppressWarnings("deprecation")
    public void UserRegister_verify(String User_Register_ActualName,String Label_XPath) throws Throwable {
    	//if(getDriver().findElement(By.xpath(ScrLr.User_Reg_exception)).getText() != null)

    	String CompleteText=Cucumberlibrary.getTextByXpath(getDriver(),Label_XPath);
    	System.out.println("entered in verification");
    	if(CompleteText.contains(User_Register_ActualName)){System.out.println(""+User_Register_ActualName+ "has logged in");}
   		else{System.out.println(""+User_Register_ActualName+ "has not logged in");}
    	
    }
    
    public void UserRegister_Signout(String User_Register_ActualName,String Login_name_XPath,String Uname_signout_XPath) throws Throwable {
    	Cucumberlibrary.clickOnElementByXpath(getDriver(),Login_name_XPath);
		Cucumberlibrary.clickOnElementByXpath(getDriver(),Uname_signout_XPath);
		System.out.println(""+User_Register_ActualName+" has logged out");
		getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }
    
    public void Close(Scenario scenario) throws Throwable { 
    if (getDriver()!= null) {
    	getDriver().close();
    	getDriver().quit();
    	}
    }
}