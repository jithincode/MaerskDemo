package demos.step;

import java.io.FileInputStream;

import cucumber.api.Scenario;
import cucumber.api.java.Before;
import junit.framework.Assert;
import net.serenitybdd.core.annotations.findby.By;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.pages.PageObject;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import bdd.demos.cucumberlibrary.ScreenLibrary;

@SuppressWarnings("static-access")   
public class SignupSteps extends PageObject {
	
	@Steps
	HomePage Hmpage;
	ScreenLibrary ScrLr;
	Properties locators = new Properties();
	
	@Before
	public void Newsetup() throws Throwable
	{
		FileInputStream objfile = new FileInputStream(System.getProperty("user.dir")+"\\serenity.properties");
		locators.load(objfile);
	}
	
	// tag::Singup[]   
    @Step                                                       
    public void opens_home_page() {   
    	Hmpage.open();
    	System.out.println("Opens home page"); 
    }
    @Step                                                       
    public void landing_page() throws Throwable {   
    	Hmpage.Pagelands();
    }    
    @Step
    public void Home_signup_clicking() throws Throwable {
		Hmpage.searchSignupButton(ScrLr.Signupbutton);		
    }
	@Step
    public void Input_Firstname(String firstName_Value) throws Throwable {
		Hmpage.SignupFirstnameText(firstName_Value);		
    }
	@Step
    public void Input_Lastname(String lastName_Value) throws Throwable {
		Hmpage.SignupLastnameText(lastName_Value);		
    }
	@Step
    public void Input_Mob_number(String Mob_number_value) throws Throwable {
		Hmpage.SignupMob_number(Mob_number_value);		
    }
	@Step
    public void Input_EmailID(String EmailID_value) throws Throwable {
		Hmpage.SignupEmailID(EmailID_value);		
    }	
	@Step
    public void Input_Password(String Password_value) throws Throwable {
		Hmpage.SignupPassword(Password_value);		
    }
	@Step
    public void Input_Confirm_Password(String ConfirmPassword_value) throws Throwable {
		Hmpage.SignupConfirmPassword(ConfirmPassword_value);		
    }	
	@Step
    public void UserRegister_Submit_clicking() throws Throwable {
		Hmpage.SignupSubmitButton(ScrLr.UserRegister_Submitbutton);	
	}
	@Step
    public void UserRegister_verification(String firstName_Actual_Value) throws Throwable {
		System.out.println("entered in verification_signup");
		Hmpage.UserRegister_verify(firstName_Actual_Value,ScrLr.Uname_label);
	}	
	@Step
    public void User_Signout(String firstName_Actual_Value) throws Throwable {
		Hmpage.UserRegister_Signout(firstName_Actual_Value,ScrLr.Login_Uname,ScrLr.Uname_signout);
	}
    @Step                                                       
    public void CloseHome_page(Scenario scenario) throws Throwable {   
    	Hmpage.Close(scenario);
    	System.out.println("Closes home page"); 
    }
  //end::Signup[]



/*    @Step
    public void should_see_items_related_to(String keywords) {
        List<String> resultTitles = searchResultsPage.getResultTitles();
        resultTitles.stream().forEach(title -> assertThat(title.contains(keywords)));
    }*/
	}

// end::searchByKeywordSteps[]
/*// tag::filterByType[]
    @Step
    public void filters_results_by_type(String type) {
        searchResultsPage.filterByType(type);
    }

    public int get_matching_item_count() {
        return searchResultsPage.getItemCount();
    }

    @Step
    public void should_see_item_count(Matcher<Integer> itemCountMatcher) {
        itemCountMatcher.matches(searchResultsPage.getItemCount());
    }


// end::filterByType[]

    ItemDetailsPage detailsPage;

    @Step
    public void selects_item_number(int number) {
        ListingItem selectedItem = searchResultsPage.selectItem(number);
        Serenity.setSessionVariable(SessionVariables.SELECTED_LISTING).to(selectedItem);

    }

    @Step
    public void should_see_matching_details(String searchTerm) {
        detailsPage.shouldContainText(searchTerm);
    }

    @Step
    public void should_see_items_of_type(String type) {
        Optional<String> selectedType = searchResultsPage.getSelectedType();
        assertThat(selectedType.isPresent()).describedAs("No item type was selected").isTrue();
        assertThat(selectedType.get()).isEqualTo(type);
    }

    @Step
    public void selects_any_product_variations() {
        detailsPage.getProductVariationIds().stream()
                .forEach(id -> detailsPage.selectVariation(id,2));
    }

    @Step
    public void should_see_item_in_cart(ListingItem selectedItem) {
        assertThat(cartPage.getOrderCostSummaries()
                .stream().anyMatch(order -> order.getName().equals(selectedItem.getName()))).isTrue();
    }

    @Step
    public void should_see_total_including_shipping_for(ListingItem selectedItem) {
        OrderCostSummary orderCostSummary
                = cartPage.getOrderCostSummaryFor(selectedItem).get();

        double itemTotal = orderCostSummary.getItemTotal();
        double shipping = orderCostSummary.getShipping();
        double totalCost = orderCostSummary.getTotalCost();

        assertThat(itemTotal).isEqualTo(selectedItem.getPrice());

        if (cartPage.isShowingShippingCosts()) {
            assertThat(shipping).isGreaterThan(0.0);
            assertThat(totalCost).isCloseTo(itemTotal + shipping, Offset.offset(0.001));
        }
    }

    @Step
    public void adds_current_item_to_shopping_cart() {
        detailsPage.addToCart();
    }

    public void filters_by_local_region() {
        searchResultsPage.filterByLocalRegion();
    }


// tag::tail[]
}*/
//end:tail
