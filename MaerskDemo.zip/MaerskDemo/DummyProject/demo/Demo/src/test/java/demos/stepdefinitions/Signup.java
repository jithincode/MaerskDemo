package demos.stepdefinitions;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import demos.step.*;

public class Signup
{	
	SignupSteps Signup_obj;
    	
	@Before()
	public void setup() throws Throwable {
		Signup_obj.opens_home_page();		
		System.out.println("FirefoxDriver : created successfully.");
	}

	@Given("^the user is on landing page$")	
	public void user_on_landing_page() throws Throwable {
		Signup_obj.landing_page();
	}		
	
	@When("^user chooses to sign up$")
	public void  user_chooses_to_sign_up() throws Throwable {
		Signup_obj.Home_signup_clicking();
	}
		
	@And("^user provides the firstname as (.*)$")
	public void user_provides_the_first_name(String firstName_Value) throws Throwable {
		Signup_obj.Input_Firstname(firstName_Value); //Parameterizing the driver from the driver_type and the signup_button x_path from the object.properties file
	}

	@And("^user provides the lastname as (.*)$")
	public void user_provides_the_last_name(String lastName_Value) throws Throwable {
		Signup_obj.Input_Lastname(lastName_Value);
	}

	@And("^user provides the mobile number as (.*)$")
	public void user_provides_the_mobilenumber(String mob) throws Throwable {
		Signup_obj.Input_Mob_number(mob);
	}
	
	@And("^user provides the email as (.*)$")
	public void user_provides_the_email(String email) throws Throwable {
		Signup_obj.Input_EmailID(email);
	}
	
	@And("^user provides the password as (.*)$")
	public void user_provides_the_password(String Password) throws Throwable {
		Signup_obj.Input_Password(Password);
	}
		
	@And("^user provides the confirm password as (.*)$")
	public void user_provides_the_confirm_password(String confirmPassword) throws Throwable	{
		Signup_obj.Input_Confirm_Password(confirmPassword);
	}
	
	@And("^user clicks the submit button$")
	public void user_clicks_signs_up() throws Throwable {
		Signup_obj.UserRegister_Submit_clicking();
	}

	@And("^User should be logged in to the application with the firstname as (.*)$")
	public void user_should_be_logged_in(String ActualfName) throws Throwable {
		Signup_obj.UserRegister_verification(ActualfName);
	}
	
	@Then("^User should be sign out as (.*)$")
	public void user_should_be_logged_out(String ActualfName) throws Throwable {
		Signup_obj.User_Signout(ActualfName);
	}
		
	@After()
    public void tearDown(Scenario scenario) throws Throwable{
		Signup_obj.CloseHome_page(scenario);
    }
}
